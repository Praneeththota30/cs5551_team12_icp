# DeltaHacks3

RLSolutions HealthCare Nutrition and Diet Mobile App:

Mission: To innovate a new way of incentivising users to follow diet and nutrition plans as laid out by their nutritionists/doctors.

Description: 
We present a typical system of entering daily intake amounts of different foods and pull from a database that holds all the nutritional information of said food item. The user is rewarded with points for inputting their meal data as an incentive to continue using the app. The app then analyzes the meals to ensure the user is following the regimen currently set up; if the user's meal data match their goals within an acceptable range, we'll increase a multiplier which will earn you more points. If you miss your target, your points multiplier will decrease. If the user stops inputting data for a day, the app will send notifications warning the user of the impending danger a few hours before breaking the streak, dropping the multiplier back down to 1. This idea came from us after noticing a trend in streak dynamics in apps; we believe it will add to user engagement and encourage use of the app. One of the most crucial features is the doctor's key addition, doctor's can make edits to their patients nutritional goals, this would be inobtrusive and would allow users to meet whatever nutritional needs they have.

Man 2500,70,56,275,38,3,34
